# -*- coding: utf-8 -*-
# @Explain  : 
# @Time     : 2021/02/02 9:46 
# @Author   : tide
# @FileName : config


class Config(object):
    """ 基础配置"""

    APP_NAME = "wox"

    KAFKA_CFG = {
        "shortest": {
            "session.timeout.ms": 6000,
            "max.poll.interval.ms": 10000,
            # "debug": "cgrp"
        },
        "short": {
            "session.timeout.ms": 30000,
            "max.poll.interval.ms": 300000,
            "heartbeat.interval.ms": 10000,
        },
        "medium": {
            "session.timeout.ms": 30000,
            "max.poll.interval.ms": 600000,
            "heartbeat.interval.ms": 10000,
        },
        "mediumest": {
            "session.timeout.ms": 30000,
            "max.poll.interval.ms": 900000,
            "heartbeat.interval.ms": 10000,
        },
        "long": {
            "session.timeout.ms": 30000,
            "max.poll.interval.ms": 1200000,
            "heartbeat.interval.ms": 10000,
        }
    }

    KAFKA_TOPICS = {
        "test_ori1": {"cluster": "default", "setting": KAFKA_CFG["shortest"]},
        "commit-log": {"cluster": "default", "setting": KAFKA_CFG["shortest"]},
        "dead-letter": {"cluster": "default", "setting": KAFKA_CFG["shortest"]},
    }

    # KAFKA配置相关
    KAFKA_CLUSTERS = {
        "default": {  # 配置参数详见: https://github.com/edenhill/librdkafka/blob/master/CONFIGURATION.md
            "bootstrap.servers": '127.0.0.1:9092',
            "group.id": "wox",
            # "group.instance.id": "wox",
            "client.id": "",
            "default.topic.config": {"auto.offset.reset": "smallest"},            # smallest、latest
            "partition.assignment.strategy": "range",  # range or roundrobin
            "debug": "generic", # generic, broker, topic, metadata, feature, queue, msg, protocol, cgrp, security, fetch, interceptor, plugin, consumer, admin, eos, mock, all
            "session.timeout.ms": 10000,  # 客户端会话超时时间
            "max.poll.interval.ms": 10000,
            # kafka消费者在每一轮poll()调用之间的最大延迟, 尽量保证一次poll的消息能够很快完成，比如需要存入hdfs、关系数据库，都需要对消耗时间进行预估，保证时间不会太长
            "enable.auto.commit": False,  # 在后台周期性的自动提交偏移量
            "auto.commit.interval.ms": 5000,  # 消费者偏移量提交（写入）到存储的频率，毫秒。(0 = 不可用)
            "enable.auto.offset.store": True,  # 自动存储提供给应用程序的最后一条消息的偏移量
            "statistics.interval.ms": 3600000,  # librdkafka统计时间间隔，应用程序也应该通过注册回调函数来实现对统计指标的监控，0禁用，单位1000ms.
            "coordinator.query.interval.ms": 60000,
            # 多久查询一次当前的客户端组协调器。 如果当前分配的协调器已关闭，则在协调器重新分配的情况下，配置的查询时间间隔将除以10以更快地恢复.
            "heartbeat.interval.ms": 3000,  # 组会话保持心跳间隔时间.
            "queued.min.messages": 200000,  # 每个主题尝试在本地使用者队列中维护的分区的最小消息数
            "acks": -1,
            "retries": 5,
            "request.required.acks": -1
        }
    }
    KAFKA_CONSUMER_AUTO_CREATE_TOPICS = True


    METRICS_BACKEND = "common.metrics.dummy.DummyMetricsBackend"
    METRICS_PREFIX = "tornado."
    METRICS_OPTIONS = {}
    METRICS_SKIP_ALL_INTERNAL = False
    METRICS_SKIP_INTERNAL_PREFIXES = []
    METRICS_SAMPLE_RATE = 1.0


# 当前没有区分环境，以默认配置
setting = Config
