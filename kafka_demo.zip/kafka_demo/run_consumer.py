# -*- coding: utf-8 -*-

from common.kafka.manager import producers
from common.kafka.ingest_consumer import IngestConsumerWorker
from common.kafka.manager import create_batching_kafka_consumer


topic = "test_ori1"
producer = producers.get(topic)
topic_names = [topic, "dead-letter"]
options = {'max_batch_size': 20, 'max_batch_time': 2000, 'group_id': "test_ori_group", "producer": producer,
           "auto_offset_reset": "smallest", "commit_log_topic": "commit-log", "dead_letter_topic": "dead-letter"}
consumer = create_batching_kafka_consumer(
    topic_names=topic_names, worker=IngestConsumerWorker(), **options
)
consumer.run()
