# -*- coding: utf-8 -*-

import json
import time
import logging
import functools
import msgpack
import _pickle as pickle
import sentry_sdk
from sentry_sdk import configure_scope
from confluent_kafka.cimpl import TopicPartition
from .batching_kafka_consumer import AbstractBatchWorker
from common import metric

UNSAFE_TAG = "_unsafe"
logger = logging.getLogger(__name__)


def mark_scope_as_unsafe():
    """
    Set the unsafe tag on the SDK scope for outgoing crashe and transactions.

    Marking a scope explicitly as unsafe allows the recursion breaker to
    decide early, before walking the stack and checking for unsafe files.
    """
    with configure_scope() as scope:
        scope.set_tag(UNSAFE_TAG, True)


def trace_func(**span_kwargs):
    def wrapper(f):
        @functools.wraps(f)
        def inner(*args, **kwargs):
            with sentry_sdk.start_transaction(**span_kwargs):
                return f(*args, **kwargs)

        return inner

    return wrapper


@metric.wraps("ingest_consumer.process_event")
def _do_process_event(message):
    # payload = message["payload"]
    # remote_addr = message.get("remote_addr")

    # Preprocess this event, which spawns either process_event or
    # save_event. Pass data explicitly to avoid fetching it again from the
    # cache.
    with sentry_sdk.start_span(op="ingest_consumer.process_event.preprocess_event"):
        pass


@trace_func(name="ingest_consumer.process_event")
def process_event(message):
    return _do_process_event(message)


class IngestConsumerWorker(AbstractBatchWorker):
    def process_message(self, message):
        print(f"topic: {message.topic()}, partition: {message.partition()}, offset: {message.offset()},"
              f"headers: {message.headers()}")
        headers = dict(message.headers() or [])
        value_format = headers.get("value_format", None)
        if value_format == b'msgpack':
            message = msgpack.unpackb(message.value(), use_list=False)
        elif value_format == b'json':
            message = json.loads(message.value())
        elif value_format == b'pickle':
            message = pickle.loads(message.value())
        else:
            message = message.value().decode()

        return message

    def flush_batch(self, batch):
        mark_scope_as_unsafe()
        with metric.timer("ingest_consumer.flush_batch"):
            return self._flush_batch(batch)

    def category_message(self, message):
        message_type = message["type"]
        if message_type == "event":
            final_message = (process_event, message)
        else:
            raise ValueError(f"Unknown message type: {message_type}")
        metric.incr(
            "ingest_consumer.flush.messages_seen", tags={"message_type": message_type}
        )
        return final_message

    def _flush_batch(self, batch):
        other_messages = []

        with metric.timer("ingest_consumer.prepare_messages"):
            for message in batch:
                other_messages.append(self.category_message(message))

        if other_messages:
            with metric.timer("ingest_consumer.process_other_messages_batch"):
                for processing_func, message in other_messages:
                    processing_func(message)

    def commit_before(self):
        pass

    def commit_failure(self, e, batch_consumer=None, try_count=3):
        if batch_consumer:
            consumer = batch_consumer.consumer
            offsets = batch_consumer.__batch_offsets
            for k, v in offsets.items():
                topic, partition = k
                for i in range(try_count):
                    try:
                        consumer.seek(TopicPartition(topic, partition, v[0]))
                        break
                    except Exception:
                        time.sleep(0.1)
                        continue

    def shutdown(self):
        pass
